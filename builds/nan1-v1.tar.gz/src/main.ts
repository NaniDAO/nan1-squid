import { EvmBatchProcessor } from '@subsquid/evm-processor'
import { assertNotNull } from '@subsquid/util-internal';
import { TypeormDatabase } from '@subsquid/typeorm-store'
import { lookupArchive } from '@subsquid/archive-registry'

import * as accountsAbi from './abi/accounts'
import { Account } from './model'
import { ACCOUNTS_ADDRESS } from './constants';
import { convertTimestampMilliToSeconds } from './utils';

const processor = new EvmBatchProcessor()
  .setGateway(lookupArchive('eth-mainnet'))
  .setRpcEndpoint({
    // set RPC endpoint in .env
    url: assertNotNull(process.env.RPC_ETH_HTTP, 'RPC_ETH_HTTP is not set'),
    rateLimit: 10
  })
  .setFinalityConfirmation(75) // 15 mins to finality
  .setBlockRange({ from: 18597775 })
  .setFields({
    transaction: {
      chainId: true,
      from: true,
      to: true,
      sighash: true,
      hash: true,
      value: true,
    },
    trace: {
      callInput: true,
      callFrom: true,
      callTo: true,
      callSighash: true,
      callResultOutput: true,
      callValue: true,
    }
  })
  .addTrace({
    type: ['call'],
    callSighash: [accountsAbi.functions.createAccount.sighash],
    callTo: [ACCOUNTS_ADDRESS],
    transaction: true,
  })

const db = new TypeormDatabase()

processor.run(db, async ctx => {
    const accounts: Account[] = []
    for (let block of ctx.blocks) {
      for (let trace of block.traces) {
        if (trace.type === 'call') {
          // @ts-expect-error
          const { from, to, value, input, sighash } = trace.action;
          ctx.log.info({ from, to, value, input, sighash }, `Processing call ${trace.transaction.hash}`)

          if (sighash === accountsAbi.functions.createAccount.sighash) {
            const [owner, salt] = accountsAbi.functions.createAccount.decode(input)
            ctx.log.info({ owner, salt }, `Processing createAccount ${trace.transaction.hash}`)
            // @ts-expect-error
            ctx.log.info({ output: trace.result.output }, `Processing createAccount ${trace.transaction.hash}`)
            // @ts-expect-error
            const account = accountsAbi.functions.createAccount.decodeResult(trace.result.output)
            
            ctx.log.info({ account }, `Processing createAccount ${trace.transaction.hash}`)

            accounts.push({
              id: account.toLowerCase() + '-' + 'eth-mainnet',
              address: account.toLowerCase(),
              owner: owner.toLowerCase(),
              salt: salt.toLowerCase(),
              txHash: trace.transaction.hash,
              blockTimestamp: convertTimestampMilliToSeconds(block.header.timestamp),
            })
            ctx.log.info({ account }, `Processed createAccount ${trace.transaction.hash}`)
          }
        }
      }
    }
    ctx.log.info({ accounts }, `Inserting ${accounts.length} accounts`)
    await ctx.store.insert(accounts).then(() => {
      ctx.log.info('Inserted accounts')
    })
})

